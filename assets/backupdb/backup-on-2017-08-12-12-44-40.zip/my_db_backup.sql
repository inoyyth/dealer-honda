#
# TABLE STRUCTURE FOR: account
#

DROP TABLE IF EXISTS `account`;

CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `nama_lengkap` varchar(255) DEFAULT NULL,
  `password` varchar(1000) DEFAULT NULL,
  `no_telp` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `path_foto` varchar(255) DEFAULT NULL,
  `access_menu` text,
  `super_admin` enum('1','2') DEFAULT '1' COMMENT '1 =>not super admin, 2 => is super admin',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime NOT NULL,
  `sys_update_date` datetime NOT NULL,
  `sys_delete_date` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  `status` enum('1','2') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `account` (`id`, `username`, `nama_lengkap`, `password`, `no_telp`, `email`, `path_foto`, `access_menu`, `super_admin`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`, `last_login`, `status`) VALUES ('6', 'admin@mandala.com', 'SUPER ADMINISTRATOR', 'Eb1eN68MrSMwrIxc1ck0fY9VlbRO21YO3e~2RAwl6wxysQcOnHLfNBAcCiCfjfmz4.O7mdcui4F4~3ME.eiZfw--', '909090909', 'supri170845@gmail.com', 'assets/images/account/3e15e47695fe78a92a28313a79875c23.jpg', 'a:26:{i:0;a:3:{s:4:\"menu\";s:2:\"23\";s:4:\"slug\";s:14:\"master-jabatan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:1;a:3:{s:4:\"menu\";s:2:\"24\";s:4:\"slug\";s:15:\"master-karyawan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:2;a:3:{s:4:\"menu\";s:2:\"26\";s:4:\"slug\";s:15:\"master-customer\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:3;a:3:{s:4:\"menu\";s:2:\"27\";s:4:\"slug\";s:12:\"master-motor\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:4;a:3:{s:4:\"menu\";s:2:\"28\";s:4:\"slug\";s:16:\"master-aksesoris\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:5;a:3:{s:4:\"menu\";s:2:\"29\";s:4:\"slug\";s:13:\"master-gudang\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:6;a:3:{s:4:\"menu\";s:2:\"30\";s:4:\"slug\";s:14:\"master-leasing\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:7;a:3:{s:4:\"menu\";s:2:\"36\";s:4:\"slug\";s:15:\"user-management\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:8;a:3:{s:4:\"menu\";s:2:\"60\";s:4:\"slug\";s:5:\"owner\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:9;a:3:{s:4:\"menu\";s:2:\"32\";s:4:\"slug\";s:9:\"penjualan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:10;a:3:{s:4:\"menu\";s:2:\"38\";s:4:\"slug\";s:11:\"kwitansi-dp\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:11;a:3:{s:4:\"menu\";s:2:\"41\";s:4:\"slug\";s:3:\"pdi\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:12;a:3:{s:4:\"menu\";s:2:\"44\";s:4:\"slug\";s:11:\"surat-jalan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:13;a:3:{s:4:\"menu\";s:2:\"42\";s:4:\"slug\";s:4:\"stnk\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:14;a:3:{s:4:\"menu\";s:2:\"59\";s:4:\"slug\";s:11:\"terima-stnk\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:15;a:3:{s:4:\"menu\";s:2:\"43\";s:4:\"slug\";s:4:\"void\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:16;a:3:{s:4:\"menu\";s:2:\"45\";s:4:\"slug\";s:5:\"stock\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:17;a:3:{s:4:\"menu\";s:2:\"46\";s:4:\"slug\";s:23:\"import-penerimaan-motor\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:18;a:3:{s:4:\"menu\";s:2:\"47\";s:4:\"slug\";s:26:\"input-penerimaan-aksesoris\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:19;a:3:{s:4:\"menu\";s:2:\"48\";s:4:\"slug\";s:12:\"motor-keluar\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:20;a:3:{s:4:\"menu\";s:2:\"50\";s:4:\"slug\";s:22:\"cetak-kwitansi-leasing\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:21;a:3:{s:4:\"menu\";s:2:\"51\";s:4:\"slug\";s:13:\"rekap-tagihan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:22;a:3:{s:4:\"menu\";s:2:\"52\";s:4:\"slug\";s:16:\"surat-pernyataan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:23;a:3:{s:4:\"menu\";s:2:\"53\";s:4:\"slug\";s:17:\"pencairan-leasing\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:24;a:3:{s:4:\"menu\";s:2:\"54\";s:4:\"slug\";s:17:\"laporan-penjualan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:25;a:3:{s:4:\"menu\";s:2:\"65\";s:4:\"slug\";s:15:\"backup-database\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}}', '2', NULL, '6', NULL, '0000-00-00 00:00:00', '2017-05-07 13:08:16', '0000-00-00 00:00:00', '2017-08-12 11:53:06', '1');
INSERT INTO `account` (`id`, `username`, `nama_lengkap`, `password`, `no_telp`, `email`, `path_foto`, `access_menu`, `super_admin`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`, `last_login`, `status`) VALUES ('7', 'sapta@gmail.com', 'Sapta', 'FPeGUTv9tqU2OK+ehIe1y8pL+LOh5ZmSomm7hY/ibO9N77b052+OaMFj/vNfzL298YcvFF/EAsBh8faI+QQvRA==', '879979797979', 'supri170845@gmail.com', '667fa1e720b199d98293f0eec4086ebe.jpg', 'a:27:{i:0;a:3:{s:4:\"menu\";s:2:\"23\";s:4:\"slug\";s:14:\"master-jabatan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:1;a:3:{s:4:\"menu\";s:2:\"24\";s:4:\"slug\";s:15:\"master-karyawan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:2;a:3:{s:4:\"menu\";s:2:\"26\";s:4:\"slug\";s:15:\"master-customer\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:3;a:3:{s:4:\"menu\";s:2:\"27\";s:4:\"slug\";s:12:\"master-motor\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:4;a:3:{s:4:\"menu\";s:2:\"28\";s:4:\"slug\";s:16:\"master-aksesoris\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:5;a:3:{s:4:\"menu\";s:2:\"29\";s:4:\"slug\";s:13:\"master-gudang\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:6;a:3:{s:4:\"menu\";s:2:\"30\";s:4:\"slug\";s:14:\"master-leasing\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:7;a:3:{s:4:\"menu\";s:2:\"37\";s:4:\"slug\";s:16:\"master-biro-jasa\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:8;a:3:{s:4:\"menu\";s:2:\"32\";s:4:\"slug\";s:9:\"penjualan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:9;a:3:{s:4:\"menu\";s:2:\"38\";s:4:\"slug\";s:11:\"kwitansi-dp\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:10;a:3:{s:4:\"menu\";s:2:\"33\";s:4:\"slug\";s:10:\"pembayaran\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:11;a:3:{s:4:\"menu\";s:2:\"41\";s:4:\"slug\";s:3:\"pdi\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:12;a:3:{s:4:\"menu\";s:2:\"42\";s:4:\"slug\";s:4:\"stnk\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:13;a:3:{s:4:\"menu\";s:2:\"59\";s:4:\"slug\";s:11:\"terima-stnk\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:14;a:3:{s:4:\"menu\";s:2:\"43\";s:4:\"slug\";s:4:\"void\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:15;a:3:{s:4:\"menu\";s:2:\"44\";s:4:\"slug\";s:11:\"surat-jalan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:16;a:3:{s:4:\"menu\";s:2:\"34\";s:4:\"slug\";s:12:\"return-motor\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:17;a:3:{s:4:\"menu\";s:2:\"45\";s:4:\"slug\";s:5:\"stock\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:18;a:3:{s:4:\"menu\";s:2:\"46\";s:4:\"slug\";s:23:\"import-penerimaan-motor\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:19;a:3:{s:4:\"menu\";s:2:\"47\";s:4:\"slug\";s:26:\"input-penerimaan-aksesoris\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:20;a:3:{s:4:\"menu\";s:2:\"48\";s:4:\"slug\";s:12:\"motor-keluar\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:21;a:3:{s:4:\"menu\";s:2:\"49\";s:4:\"slug\";s:11:\"motor-masuk\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:22;a:3:{s:4:\"menu\";s:2:\"50\";s:4:\"slug\";s:22:\"cetak-kwitansi-leasing\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:23;a:3:{s:4:\"menu\";s:2:\"51\";s:4:\"slug\";s:13:\"rekap-tagihan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:24;a:3:{s:4:\"menu\";s:2:\"52\";s:4:\"slug\";s:16:\"surat-pernyataan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:25;a:3:{s:4:\"menu\";s:2:\"53\";s:4:\"slug\";s:17:\"pencairan-leasing\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}i:26;a:3:{s:4:\"menu\";s:2:\"54\";s:4:\"slug\";s:17:\"laporan-penjualan\";s:5:\"child\";a:4:{s:3:\"add\";i:1;s:3:\"upd\";i:1;s:3:\"del\";i:1;s:3:\"prt\";i:1;}}}', '1', NULL, '6', NULL, '0000-00-00 00:00:00', '2017-03-12 01:16:44', '0000-00-00 00:00:00', '2017-03-12 01:13:19', '1');


#
# TABLE STRUCTURE FOR: covernote_history
#

DROP TABLE IF EXISTS `covernote_history`;

CREATE TABLE `covernote_history` (
  `id_covernote` int(11) NOT NULL AUTO_INCREMENT,
  `noso_covernote` varchar(50) DEFAULT NULL,
  `print_format_id` int(11) DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_covernote`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: detail_motor_keluar
#

DROP TABLE IF EXISTS `detail_motor_keluar`;

CREATE TABLE `detail_motor_keluar` (
  `id_motor_keluar` int(11) NOT NULL AUTO_INCREMENT,
  `id_detail_motor_keluar` int(11) NOT NULL,
  `no_mesin` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_motor_keluar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: detail_motor_keluar_temp
#

DROP TABLE IF EXISTS `detail_motor_keluar_temp`;

CREATE TABLE `detail_motor_keluar_temp` (
  `id_detail_motor_keluar` int(11) NOT NULL AUTO_INCREMENT,
  `no_mesin` varchar(50) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_detail_motor_keluar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: global_data
#

DROP TABLE IF EXISTS `global_data`;

CREATE TABLE `global_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_data` varchar(50) NOT NULL,
  `value` varchar(100) DEFAULT NULL,
  `global_data_status` enum('1','2','3') DEFAULT NULL COMMENT '1(Aktif), 2(In-Aktif), 3(Delete)',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `global_data` (`id`, `group_data`, `value`, `global_data_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('1', 'aksesoris', 'aki', '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `global_data` (`id`, `group_data`, `value`, `global_data_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('2', 'aksesoris', 'spion', '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `global_data` (`id`, `group_data`, `value`, `global_data_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('3', 'aksesoris', 'helm', '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `global_data` (`id`, `group_data`, `value`, `global_data_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('4', 'cpembelian', 'Cash', '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `global_data` (`id`, `group_data`, `value`, `global_data_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('5', 'cpembelian', 'Kredit', '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `global_data` (`id`, `group_data`, `value`, `global_data_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('6', 'aksesoris', 'toolkit', '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `global_data` (`id`, `group_data`, `value`, `global_data_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('7', 'aksesoris', 'rumah_plat', '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `global_data` (`id`, `group_data`, `value`, `global_data_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('8', 'aksesoris', 'jacket', '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `global_data` (`id`, `group_data`, `value`, `global_data_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('9', 'aksesoris', 'jas_hujan', '1', NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: m_aksesoris
#

DROP TABLE IF EXISTS `m_aksesoris`;

CREATE TABLE `m_aksesoris` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kd_aksesoris` varchar(20) NOT NULL,
  `aksesoris` varchar(35) NOT NULL,
  `kategori` int(11) NOT NULL,
  `url_foto` text NOT NULL,
  `m_status` enum('1','2','3') NOT NULL DEFAULT '1',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('1', 'GLS', 'SPION GLS', '2', 'assets/images/aksesoris/icon.png', '1', '6', '6', NULL, '2017-05-06 14:54:30', '2017-05-06 14:57:27', NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('2', 'K03S', 'SPION K03S', '2', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:55:02', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('3', 'K16A', 'SPION K16A', '2', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:55:18', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('4', 'K18A', 'SPION K18A', '2', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:55:33', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('5', 'K25A', 'SPION K25A', '2', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:55:47', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('6', 'K2LG', 'SPION K2LG', '2', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:56:03', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('7', 'K2RA', 'SPION K2RA', '2', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:56:16', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('8', 'K45G', 'SPION K45G', '2', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:56:37', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('9', 'K56A', 'SPION K56A', '2', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:56:57', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('10', 'K56F', 'SPION K56F', '2', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:57:12', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('11', 'K61A', 'SPION K61A', '2', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:57:48', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('12', 'K81A', 'SPION K81A', '2', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:58:01', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('13', 'NF100T', 'SPION NF100T', '2', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:58:16', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('14', 'GENERAL', 'TOOLKIT GENERAL', '6', 'assets/images/aksesoris/icon.png', '3', '6', NULL, '6', '2017-05-06 14:58:45', NULL, '2017-05-06 14:59:28');
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('15', 'T-GENERAL', 'TOOLKIT GENERAL', '6', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 14:59:47', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('16', 'T-CB150', 'TOOLKIT CB 150', '6', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 15:00:07', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('17', 'T-CBR150', 'TOOLKIT CBR150', '6', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 15:00:24', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('18', 'T-MEGAPRO', 'TOOLKIT MEGAPRO', '6', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 15:00:42', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('19', 'T-SONIC', 'TOOLKIT SONIC', '6', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 15:00:59', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('20', 'T-SPACY', 'TOOLKIT SPACY', '6', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 15:01:16', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('21', 'T-SUPRA GTR', 'TOOLKIT SUPRA GTR', '6', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 15:01:38', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('22', 'T-VERZA', 'TOOLKIT VERZA', '6', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 15:01:55', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('23', 'T- SUPRA X HI', 'TOOLKIT SUPRA X HELM IN', '6', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 15:02:39', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('24', 'AKI-4V', 'AKI 4V', '1', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 15:03:00', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('25', 'AKI-5V', 'AKI 5V', '1', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 15:03:14', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('26', 'AKI-6V', 'AKI 6V', '1', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 15:03:25', NULL, NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('27', 'H-TRX-3', 'HELM TRX-3', '3', 'assets/images/aksesoris/0a083c1cd4ff1e6e1c10bb829f9942e6.jpg', '1', '6', '6', NULL, '2017-05-06 15:03:54', '2017-05-06 15:06:20', NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('28', 'H-TRX-R', 'HELM TRX-R', '3', 'assets/images/aksesoris/2e3f310412d46cdbaaf4e0ec1b59174c.jpg', '1', '6', '6', NULL, '2017-05-06 15:04:12', '2017-05-06 15:06:31', NULL);
INSERT INTO `m_aksesoris` (`id`, `kd_aksesoris`, `aksesoris`, `kategori`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('29', 'H-TRX-S', 'HELM TRX-S', '3', 'assets/images/aksesoris/icon.png', '1', '6', NULL, NULL, '2017-05-06 15:04:30', NULL, NULL);


#
# TABLE STRUCTURE FOR: m_backup_db
#

DROP TABLE IF EXISTS `m_backup_db`;

CREATE TABLE `m_backup_db` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_file` text,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

INSERT INTO `m_backup_db` (`id`, `backup_file`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('22', 'backup-on-2017-05-07-13-11-02.zip', '6', NULL, NULL, '2017-05-07 13:11:02', NULL, NULL);
INSERT INTO `m_backup_db` (`id`, `backup_file`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('23', 'backup-on-2017-05-07-13-17-08.zip', '6', NULL, NULL, '2017-05-07 13:17:08', NULL, NULL);
INSERT INTO `m_backup_db` (`id`, `backup_file`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('24', 'backup-on-2017-07-15-17-47-10.zip', '6', NULL, NULL, '2017-07-15 17:47:10', NULL, NULL);


#
# TABLE STRUCTURE FOR: m_biro_jasa
#

DROP TABLE IF EXISTS `m_biro_jasa`;

CREATE TABLE `m_biro_jasa` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama_birojasa` varchar(50) DEFAULT NULL,
  `telepon_birojasa` varchar(20) DEFAULT NULL,
  `handphone_birojasa` varchar(20) DEFAULT NULL,
  `alamat_birojasa` text,
  `pic_birojasa` varchar(50) DEFAULT NULL,
  `pic_kontak_birojasa` varchar(20) DEFAULT NULL,
  `email_birojasa` varchar(50) DEFAULT NULL,
  `status_birojasa` int(11) DEFAULT '2',
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `m_biro_jasa` (`id`, `nama_birojasa`, `telepon_birojasa`, `handphone_birojasa`, `alamat_birojasa`, `pic_birojasa`, `pic_kontak_birojasa`, `email_birojasa`, `status_birojasa`, `sys_create_date`, `sys_update_date`, `sys_delete_date`, `sys_create_user`, `sys_update_user`, `sys_delete_user`) VALUES ('1', 'TEGUH JAYA', '02155952617', '02155952617', 'CITRA 2 JAKARTA BARAT', 'JOHANES HAMBALI', '02155952617', 'BJTJYUNGS@GMAIL.COM', '1', '2017-05-06 14:48:25', NULL, NULL, '6', NULL, NULL);


#
# TABLE STRUCTURE FOR: m_customer
#

DROP TABLE IF EXISTS `m_customer`;

CREATE TABLE `m_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_ktp` varchar(30) NOT NULL DEFAULT '',
  `nama_customer` varchar(100) DEFAULT NULL,
  `tempat_lahir_customer` varchar(50) DEFAULT NULL,
  `tanggal_lahir_customer` date DEFAULT NULL,
  `kelamin_customer` enum('P','W') DEFAULT NULL,
  `alamat_customer` text,
  `telepon_customer` varchar(20) DEFAULT NULL,
  `handphone_customer` varchar(20) DEFAULT NULL,
  `rt` varchar(10) DEFAULT NULL,
  `rw` varchar(10) DEFAULT NULL,
  `wilayah` varchar(75) DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `m_status` enum('1','2','3') DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`no_ktp`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `m_customer` (`id`, `no_ktp`, `nama_customer`, `tempat_lahir_customer`, `tanggal_lahir_customer`, `kelamin_customer`, `alamat_customer`, `telepon_customer`, `handphone_customer`, `rt`, `rw`, `wilayah`, `kelurahan`, `kecamatan`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('1', '3171032402860014', 'Fredy Halim', 'Pontianak', '2017-05-06', 'P', 'cempaka sari 2A/36', '0214204245', '081808881898', '010', '008', 'Jakarta Pusat', 'Harapan Mulya', 'Cempaka Putih', '1', NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: m_gudang
#

DROP TABLE IF EXISTS `m_gudang`;

CREATE TABLE `m_gudang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kd_gudang` varchar(10) NOT NULL,
  `gudang` varchar(100) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `pic` varchar(100) DEFAULT NULL,
  `status_gudang` enum('1','2','3') DEFAULT NULL COMMENT '1(Aktif), 2(In-Aktif), 3(Delete)',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`kd_gudang`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `m_gudang` (`id`, `kd_gudang`, `gudang`, `alamat`, `telepon`, `pic`, `status_gudang`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('1', 'WRH-0001', 'GUDANG DEALER', 'JL. BEKASI TIMUR RAYA NO. 158 JAKARTA TIMUR', '0218517620', 'SUWARTO', '1', '6', NULL, NULL, '2017-05-06 14:41:33', NULL, NULL);
INSERT INTO `m_gudang` (`id`, `kd_gudang`, `gudang`, `alamat`, `telepon`, `pic`, `status_gudang`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('2', 'WRH-0002', 'GUDANG MK', 'MUARA KARANG JAKARTA UTARA', '02166605419', 'SUNJAYA', '1', '6', NULL, NULL, '2017-05-06 14:42:12', NULL, NULL);


#
# TABLE STRUCTURE FOR: m_jabatan
#

DROP TABLE IF EXISTS `m_jabatan`;

CREATE TABLE `m_jabatan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jabatan` varchar(200) DEFAULT NULL,
  `keterangan` text,
  `status_jabatan` enum('1','2','3') DEFAULT '1' COMMENT '1(Aktif), 2(In-Aktif), 3(Delete)',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `m_jabatan` (`id`, `jabatan`, `keterangan`, `status_jabatan`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('1', 'ADMINISTRASI', '', '1', '6', NULL, NULL, '2017-05-06 15:07:51', NULL, NULL);
INSERT INTO `m_jabatan` (`id`, `jabatan`, `keterangan`, `status_jabatan`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('2', 'SOPIR', '', '1', '6', NULL, NULL, '2017-05-06 15:07:59', NULL, NULL);
INSERT INTO `m_jabatan` (`id`, `jabatan`, `keterangan`, `status_jabatan`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('3', 'MANAGER', '', '1', '6', NULL, NULL, '2017-05-06 15:08:08', NULL, NULL);


#
# TABLE STRUCTURE FOR: m_karyawan
#

DROP TABLE IF EXISTS `m_karyawan`;

CREATE TABLE `m_karyawan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kd_karyawan` varchar(10) NOT NULL,
  `karyawan` varchar(75) DEFAULT NULL,
  `kd_jabatan_karyawan` varchar(10) DEFAULT NULL COMMENT 'kd_jabatan_karyawan didapat dari table m_jabatan',
  `tgl_masuk` date DEFAULT NULL,
  `tgl_keluar` date DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `status_karyawan` enum('1','2','3') DEFAULT NULL COMMENT '1(Aktif), 2(In-Aktif), 3(Delete)',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`kd_karyawan`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `m_karyawan` (`id`, `kd_karyawan`, `karyawan`, `kd_jabatan_karyawan`, `tgl_masuk`, `tgl_keluar`, `foto`, `status_karyawan`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('1', 'EMP-0001', 'HERLINA WIDYASTUTY', '1', '2017-05-01', '0000-00-00', 'assets/images/karyawan/icon.png', '1', '6', '6', NULL, '2017-05-06 15:09:04', '2017-05-06 16:50:47', NULL);


#
# TABLE STRUCTURE FOR: m_leasing
#

DROP TABLE IF EXISTS `m_leasing`;

CREATE TABLE `m_leasing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kd_leasing` varchar(10) NOT NULL,
  `leasing` varchar(100) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pic` varchar(50) NOT NULL COMMENT 'PIC mengambil dari m_karyawan',
  `hp` varchar(20) DEFAULT NULL,
  `kalimat_kw_1` text,
  `kalimat_kw_2` text,
  `status_leasing` enum('1','2','3') DEFAULT NULL COMMENT '1(Aktif), 2(In-Aktif), 3(Delete)',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`kd_leasing`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `m_leasing` (`id`, `kd_leasing`, `leasing`, `alamat`, `telepon`, `email`, `pic`, `hp`, `kalimat_kw_1`, `kalimat_kw_2`, `status_leasing`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('1', 'FIF', 'FEDERAL INTERNATIONAL FINANCE', '-', '0210000000', 'a@fifgroup.co.id', 'AFFANDI', '081281053109', 'JASA PERANTARA MBD', '-', '1', '6', '6', NULL, '2017-05-06 14:45:05', '2017-05-06 14:46:45', NULL);
INSERT INTO `m_leasing` (`id`, `kd_leasing`, `leasing`, `alamat`, `telepon`, `email`, `pic`, `hp`, `kalimat_kw_1`, `kalimat_kw_2`, `status_leasing`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('2', 'WOM', 'WOM Finance', '-', '0210000000', 'a@wom.co.id', 'ERIKSON', '0817888061', 'TAGIHAN KOMISI', '-', '1', '6', '6', NULL, '2017-05-06 14:46:28', '2017-05-06 14:46:55', NULL);
INSERT INTO `m_leasing` (`id`, `kd_leasing`, `leasing`, `alamat`, `telepon`, `email`, `pic`, `hp`, `kalimat_kw_1`, `kalimat_kw_2`, `status_leasing`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('3', 'MPMF', 'MITRA PINASTHIKA MUSTIKA FINANCE', 'Gedung Lippo Kuningan Lt. 23 & 25, Jl. H.R. Rasuna Said Kav. B-12, RT.6/RW.7, Karet Kuningan, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12910, Indonesia', '0816257276', 'a@wom.co.id', 'DEDIH', '0800000000', 'SUBSIDI', '-', '1', '6', '6', NULL, '2017-05-06 16:04:40', '2017-05-06 16:16:31', NULL);
INSERT INTO `m_leasing` (`id`, `kd_leasing`, `leasing`, `alamat`, `telepon`, `email`, `pic`, `hp`, `kalimat_kw_1`, `kalimat_kw_2`, `status_leasing`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('4', 'MCF', 'MEGA CENTRAL FINANCE', 'Jalan Letjen. S. Parman Kav. 76, Slipi, RT.4/RW.3, Slipi, Palmerah, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11410, Indonesia', '02153666627', 'a@mcf.co.id', '-', '0800000000', 'KOMISI PERANTARA', '-', '1', '6', '6', NULL, '2017-05-06 16:05:28', '2017-05-06 16:15:39', NULL);
INSERT INTO `m_leasing` (`id`, `kd_leasing`, `leasing`, `alamat`, `telepon`, `email`, `pic`, `hp`, `kalimat_kw_1`, `kalimat_kw_2`, `status_leasing`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('5', 'SOF', 'SUMMIT OTO FINANCE', 'Komplek Ruko Mega Grosir Cempaka Mas Blok E No. 11-12, Jl. Letjend Suprapto, RW.8, Sumur Batu, Kemayoran, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10460, Indonesia', '02142870688', 'a@sof.com', '-', '0800000000', 'SUBSIDI', '-', '1', '6', '6', NULL, '2017-05-06 16:06:19', '2017-05-06 16:14:50', NULL);
INSERT INTO `m_leasing` (`id`, `kd_leasing`, `leasing`, `alamat`, `telepon`, `email`, `pic`, `hp`, `kalimat_kw_1`, `kalimat_kw_2`, `status_leasing`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('6', 'MF', 'MEGA FINANCE', 'Tarum Barat No.24, RT.12/RW.7, Cipinang Melayu, Makasar, Kota Jakarta Timur, Daerah Khusus Ibukota Jakarta 13620, Indonesia', '0210000000', 'a@wom.co.id', 'OYAN', '0800000000', '-', '-', '1', '6', '6', NULL, '2017-05-06 16:07:09', '2017-05-06 16:13:27', NULL);
INSERT INTO `m_leasing` (`id`, `kd_leasing`, `leasing`, `alamat`, `telepon`, `email`, `pic`, `hp`, `kalimat_kw_1`, `kalimat_kw_2`, `status_leasing`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('7', 'IMFI', 'INDOMOBIL FINANCE INDONESIA', 'Jl. Boulevard Bar. Raya, RT.18/RW.8, Klp. Gading Bar., Klp. Gading, Kota Jkt Utara, Daerah Khusus Ibukota Jakarta 14240, Indonesia', '02145853125', 'a@imfi.com', 'JONY', '0800000000', 'SUBSIDI', '-', '1', '6', '6', NULL, '2017-05-06 16:08:27', '2017-05-06 16:12:50', NULL);
INSERT INTO `m_leasing` (`id`, `kd_leasing`, `leasing`, `alamat`, `telepon`, `email`, `pic`, `hp`, `kalimat_kw_1`, `kalimat_kw_2`, `status_leasing`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('8', 'ADIRA', 'ADIRA DINAMIKA MULTI FINANCE', ' Komplek Ruko Kokan Permata, Blok F 3A-7, Jalan Boulevard Bukit Gading Raya, RT.15/RW.3, Klp. Gading Bar., Klp. Gading, Kota Jkt Utara, Daerah Khusus Ibukota Jakarta 14240, Indonesia', '02145851314', 'a@adira.com', 'HENDRO', '0800000000', '-', '-', '1', '6', NULL, NULL, '2017-05-06 16:11:06', NULL, NULL);


#
# TABLE STRUCTURE FOR: m_motor
#

DROP TABLE IF EXISTS `m_motor`;

CREATE TABLE `m_motor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipe_motor` varchar(25) NOT NULL DEFAULT '',
  `nama_motor` varchar(50) DEFAULT 'unknow-name',
  `varian` varchar(50) DEFAULT 'unknown-varian',
  `merk` varchar(50) DEFAULT 'unknown-merk',
  `harga_otr` float DEFAULT '0',
  `nama_foto` text,
  `url_foto` text,
  `m_status` enum('1','2','3') DEFAULT '1',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`tipe_motor`),
  UNIQUE KEY `unique_A` (`tipe_motor`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=743 DEFAULT CHARSET=latin1;

INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('1', 'D1B2N2L2', 'HONDA BEAT CBS', 'MATIC', 'HONDA', '15425000', 'assets/images/motor/cef51ede7ed5188da65b78a692afa73e.png', '/assets/images//assets/images/motor/cef51ede7ed5188da65b78a692afa73e.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:13:49', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('7', 'D1B2N6L2', 'HONDA BEAT CW', 'MATIC', 'HONDA', '15225000', 'assets/images/motor/e7b3be0725a3b011038bc5f107c19984.png', '/assets/images//assets/images/motor/e7b3be0725a3b011038bc5f107c19984.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:15:43', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('8', 'EF02N11S', 'HONDA VARIO 125 CBS', 'MATIC', 'HONDA', '18225000', 'assets/images/motor/8b4a4ea21e0d88b8643619d083bee169.png', '/assets/images//assets/images/motor/8b4a4ea21e0d88b8643619d083bee169.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:17:17', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('13', 'EF02N12S', 'HONDA VARIO 125 ISS', 'MATIC', 'HONDA', '18825000', 'assets/images/motor/58035a5f29d78ba49ca1545e644fa00b.png', '/assets/images//assets/images/motor/58035a5f29d78ba49ca1545e644fa00b.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:18:22', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('25', 'K1H2N14S', 'HONDA VARIO 150', 'MATIC', 'HONDA', '21975000', 'assets/images/motor/5adfcd6cba0c5189957373e7798090be.png', '/assets/images//assets/images/motor/5adfcd6cba0c5189957373e7798090be.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:23:37', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('26', 'D1B2N3L2', 'HONDA BEAT ISS', 'MATIC', 'HONDA', '16275000', 'assets/images/motor/e2d108da18404a4f5865d0e73ce2a02f.png', '/assets/images//assets/images/motor/e2d108da18404a4f5865d0e73ce2a02f.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:20:14', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('28', 'YG2N15L1', 'HONDA BEAT POP ISS', 'MATIC', 'HONDA', '15475000', 'assets/images/motor/0317176557d5623a1b1d8693188a3619.png', '/assets/images//assets/images/motor/0317176557d5623a1b1d8693188a3619.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:21:46', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('61', 'D1I2N2M1', 'HONDA BEAT STREET', 'MATIC', 'HONDA', '15925000', 'assets/images/motor/19d1c5a896bdb5200d0d17a5c51b2cca.png', '/assets/images//assets/images/motor/19d1c5a896bdb5200d0d17a5c51b2cca.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:24:46', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('62', 'F1C2N2LA', 'HONDA SCOOPY STYLISH', 'MATIC', 'HONDA', '17850000', 'assets/images/motor/ba5196cc38269d51954f36c7c833e10b.png', '/assets/images//assets/images/motor/ba5196cc38269d51954f36c7c833e10b.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:27:59', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('65', 'F1C2N2LB', 'HONDA SCOOPY SPORTY', 'MATIC', 'HONDA', '17850000', 'assets/images/motor/9670ddbd040956c2a90d4cae20814d07.png', '/assets/images//assets/images/motor/9670ddbd040956c2a90d4cae20814d07.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:27:44', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('68', 'F1C2N2LC', 'HONDA SCOOPY PLAYFUL', 'MATIC', 'HONDA', '17850000', 'assets/images/motor/37b9cbde64643129a06617edbb4efdc8.png', '/assets/images//assets/images/motor/37b9cbde64643129a06617edbb4efdc8.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:28:57', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('78', 'D1A2N18S', 'HONDA VARIO 110 CBS STD', 'MATIC', 'HONDA', '16725000', 'assets/images/motor/cf5d9b08e3d3a2a8618948806a70e0e3.png', '/assets/images//assets/images/motor/cf5d9b08e3d3a2a8618948806a70e0e3.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:30:14', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('85', 'AFX21C08', 'SUPRA X125 CW', 'CUB', 'HONDA', '17925000', 'assets/images/motor/1b5cf202ce155f2f3b3efbc079b2cc8d.png', '/assets/images//assets/images/motor/1b5cf202ce155f2f3b3efbc079b2cc8d.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:34:31', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('87', 'GL15C21A', 'HONDA MEGAPRO', 'SPORT', 'HONDA', '21825000', 'assets/images/motor/8b57363325ade6c892b244ecab606e7f.png', '/assets/images//assets/images/motor/8b57363325ade6c892b244ecab606e7f.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:34:15', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('88', 'H5C2R2S1', 'HONDA CB 150R', 'SPORT', 'HONDA', '26025000', 'assets/images/motor/1383b178972329d76a3ce9c1eca893ef.png', '/assets/images//assets/images/motor/1383b178972329d76a3ce9c1eca893ef.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:35:40', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('90', 'K1H2N4S2', 'HONDA VARIO 150', 'MATIC', 'HONDA', '21975000', 'assets/images/motor/9c6b33ac3a462709d26658cf3deaa9e5.png', '/assets/images//assets/images/motor/9c6b33ac3a462709d26658cf3deaa9e5.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:38:16', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('93', 'NFT13C01', 'HONDA REVO FIT', 'CUB', 'HONDA', '13675000', 'assets/images/motor/df05ce2503914fa8907a59810c8332d8.png', '/assets/images//assets/images/motor/df05ce2503914fa8907a59810c8332d8.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:40:22', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('95', 'NFT13C03', 'HONDA REVO CW', 'CUB', 'HONDA', '15275000', 'assets/images/motor/d17f2f70eea52bcb3ba926fbff355682.png', '/assets/images//assets/images/motor/d17f2f70eea52bcb3ba926fbff355682.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:40:48', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('139', 'D1A2N8SA', 'HONDA VARIO 110 CBS ADV', 'MATIC', 'HONDA', '16825000', 'assets/images/motor/a5fcf2551d9a7f037d6c3909cc702335.png', '/assets/images//assets/images/motor/a5fcf2551d9a7f037d6c3909cc702335.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:41:41', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('140', 'D1A2N9SA', 'HONDA VARIO 110 ISS ADV', 'MATIC', 'HONDA', '17625000', 'assets/images/motor/ae026008765aff2f2da22fe170b0ac41.png', '/assets/images//assets/images/motor/ae026008765aff2f2da22fe170b0ac41.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:42:14', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('154', 'D1A2N19S', 'HONDA VARIO 110 ISS STD', 'MATIC', 'HONDA', '17525000', 'assets/images/motor/764f3460d866328f4b37dd415ce15217.png', '/assets/images//assets/images/motor/764f3460d866328f4b37dd415ce15217.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:42:47', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('180', 'EF2N12S2', 'HONDA VARIO 125 ISS', 'MATIC', 'HONDA', '18825000', 'assets/images/motor/ffa47287ecc062f5fbfee5e76aa285a5.png', '/assets/images//assets/images/motor/ffa47287ecc062f5fbfee5e76aa285a5.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:44:17', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('189', 'H5C2R2SA', 'HONDA CB 150 R SE XM', 'SPORT', 'HONDA', '27425000', 'assets/images/motor/db152a070a33fdb9f78cf0a0e3057695.png', '/assets/images//assets/images/motor/db152a070a33fdb9f78cf0a0e3057695.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:45:36', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('222', 'P5E02RM1', 'HONDA CBR 150 R STD', 'SPORT', 'HONDA', '33025000', 'assets/images/motor/4f64dde459cb7f8559904eb00f1782fd.png', '/assets/images//assets/images/motor/4f64dde459cb7f8559904eb00f1782fd.png', '1', NULL, '6', NULL, NULL, '2017-05-06 15:50:31', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('245', 'Y3B2R17S', 'NEW SONIC 150R STD', 'SPORT', 'HONDA', '21875000', 'assets/images/motor/06c2090d409372759f38ec2e2d6ce1ab.png', '/assets/images//assets/images/motor/06c2090d409372759f38ec2e2d6ce1ab.png', '1', NULL, '6', NULL, NULL, '2017-05-06 16:00:33', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('246', 'Y3B2R71B', 'NEW SONIC 150R SPECIAL', 'SPORT', 'HONDA', '22275000', 'assets/images/motor/5acbb75e7c676edd9241ff3d90a46686.png', '/assets/images//assets/images/motor/5acbb75e7c676edd9241ff3d90a46686.png', '1', NULL, '6', NULL, NULL, '2017-05-06 16:00:25', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('262', 'P5E02RMA', 'HONDA CBR 150 R RED', 'SPORT', 'HONDA', '33725000', 'assets/images/motor/1e474f89530618442ba54b8afcabb3ab.jpg', '/assets/images//assets/images/motor/1e474f89530618442ba54b8afcabb3ab.jpg', '1', NULL, '6', NULL, NULL, '2017-05-06 16:01:59', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('288', 'NC1D1CF1', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('297', 'X12BN4LO', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('298', 'YG02N2L1', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('304', 'YG2N2LAA', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('309', 'YG2N15LA', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('310', 'EF2N11S2', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('319', 'EF2N1252', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('333', 'D1A2N8A', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('334', 'D1B2N3LA', 'HONDA BEAT ISS', 'MATIC', 'HONDA', '16280000', 'assets/images/motor/icon.png', '/assets/images//assets/images/motor/icon.png', '1', NULL, '6', NULL, NULL, '2017-08-12 12:44:20', NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('356', 'D1I2NM1', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('358', 'D112NM1', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('383', 'FIC2N2AB', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('388', 'G2E02RLA', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('390', 'G2E02RS1', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('392', 'GL15BDF2', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('393', 'GL15BF2A', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('404', 'H5C2R2SJ', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('409', 'H5C2R2MA', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('411', 'H5C2R2JA', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('414', 'P5E02MBJ', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('416', 'P5E02S1J', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `m_motor` (`id`, `tipe_motor`, `nama_motor`, `varian`, `merk`, `harga_otr`, `nama_foto`, `url_foto`, `m_status`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('422', 'K1H2N4A2', 'unknow-name', 'unknown-varian', 'unknown-merk', '0', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: m_owner
#

DROP TABLE IF EXISTS `m_owner`;

CREATE TABLE `m_owner` (
  `id` int(11) NOT NULL DEFAULT '0' COMMENT 'ID harus nilainya 1',
  `company_name` varchar(100) DEFAULT NULL,
  `owner_name` varchar(50) DEFAULT NULL,
  `owner_ktp` varchar(50) DEFAULT NULL,
  `owner_telp` varchar(20) DEFAULT NULL,
  `owner_handphone` varchar(20) DEFAULT NULL,
  `owner_email` varchar(50) DEFAULT NULL,
  `owner_address` text,
  `owner_npwp` varchar(50) DEFAULT NULL,
  `owner_jabatan` varchar(50) DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `m_owner` (`id`, `company_name`, `owner_name`, `owner_ktp`, `owner_telp`, `owner_handphone`, `owner_email`, `owner_address`, `owner_npwp`, `owner_jabatan`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('1', 'PT.MANDALA KEKAR ABADI', 'Sunjaya, SE', '3172011302660004', '02185910473', '08121006028', 'sunjaya.houwie@gmail.com', 'Jl. Raya Bekasi Timur No. 158, Cipinang - Jakarta Timur', '069386522015000', 'Direktur Utama', NULL, '6', NULL, NULL, '2017-05-06 14:53:11', NULL);


#
# TABLE STRUCTURE FOR: m_supplier
#

DROP TABLE IF EXISTS `m_supplier`;

CREATE TABLE `m_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kdsupplier` varchar(15) NOT NULL,
  `supplier` varchar(100) NOT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `telp` varchar(15) DEFAULT NULL,
  `pic` varchar(75) DEFAULT NULL,
  `hp` varchar(25) DEFAULT NULL,
  `m_status` int(2) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: m_supplier_old
#

DROP TABLE IF EXISTS `m_supplier_old`;

CREATE TABLE `m_supplier_old` (
  `kd_supplier` varchar(10) NOT NULL,
  `supplier` varchar(75) DEFAULT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `telpon` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `status_supplier` enum('1','2','3') DEFAULT NULL COMMENT '1(Aktif), 2(In-Aktif), 3(Delete)',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`kd_supplier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: menus
#

DROP TABLE IF EXISTS `menus`;

CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) DEFAULT NULL,
  `module` varchar(100) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `icon` varchar(30) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `number` int(11) NOT NULL,
  `status` enum('1','2') DEFAULT '2',
  PRIMARY KEY (`id`),
  KEY `parent` (`parent`) USING BTREE,
  CONSTRAINT `fkmenuparentid` FOREIGN KEY (`parent`) REFERENCES `menus` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;

INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('1', NULL, '-', 'Master', 'fa fa-home', 'javascript:void(0);', '1', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('2', NULL, '-', 'Transaksi', 'fa fa-edit', 'javascript:void(0);', '2', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('3', NULL, '-', 'Inventory', 'fa fa-tasks', 'javascript:void(0);', '3', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('4', NULL, '-', 'Leasing', 'fa fa-users', 'javascript:void(0);', '4', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('5', NULL, '-', 'Laporan', 'fa fa-envelope', 'javascript:void(0);', '5', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('6', NULL, '-', 'Setting', 'fa fa-cogs', 'javascript:void(0);', '6', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('23', '1', 'md_jabatan', 'Master Jabatan', 'fa fa-circle', 'master-jabatan', '1', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('24', '1', 'md_karyawan', 'Master Karyawan', 'fa fa-circle', 'master-karyawan', '2', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('26', '1', 'md_customer', 'Master Customer', 'fa fa-circle', 'master-customer', '3', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('27', '1', 'md_motor', 'Master Motor', 'fa fa-circle', 'master-motor', '4', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('28', '1', 'md_aksesoris', 'Master Aksesoris', 'fa fa-circle', 'master-aksesoris', '5', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('29', '1', 'md_gudang', 'Master Gudang', 'fa fa-circle', 'master-gudang', '6', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('30', '1', 'md_leasing', 'Master Leasing', 'fa fa-circle', 'master-leasing', '7', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('32', '2', 't_penjualan', 'Penjualan', 'fa fa-circle', 'penjualan', '1', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('36', '1', 'account', 'Users Management', 'fa fa-circle', 'user-management', '9', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('38', '2', 't_kwitansi', 'Kwitansi DP', 'fa fa-circle', 'kwitansi-dp', '2', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('41', '2', 't_pdi', 'PDI', 'fa fa-circle', 'pdi', '3', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('42', '2', 't_stnk_bpkb', 'STNK & BPKB', 'fa fa-circle', 'stnk', '5', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('43', '2', 't_void', 'Void', 'fa fa-circle', 'void', '7', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('44', '2', 't_surat_jalan', 'Surat Jalan', 'fa fa-circle', 'surat-jalan', '4', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('45', '3', 'stok', 'Stok', 'fa fa-circle', 'stock', '1', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('46', '3', 'motor_terima', 'Penerimaan Motor', 'fa fa-circle', 'import-penerimaan-motor', '2', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('47', '3', 'input_penerimaan', 'Penerimaan Aksesoris', 'fa fa-circle', 'input-penerimaan-aksesoris', '3', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('48', '3', 'motor_keluar', 'Mutasi Motor', 'fa fa-circle', 'motor-keluar', '4', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('50', '4', 'leasing/cetak_kwitansi_leasing', 'Cetak Kwitansi', 'fa fa-circle', 'cetak-kwitansi-leasing', '1', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('51', '4', 'leasing/rekap_tagihan', 'Rekap Tagihan', 'fa fa-circle', 'rekap-tagihan', '2', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('52', '4', 'leasing_covernote', 'Surat Pernyataan', 'fa fa-circle', 'surat-pernyataan', '3', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('53', '4', 'pencairan_leasing', 'Pencairan Leasing', 'fa fa-circle', 'pencairan-leasing', '4', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('54', '5', 'laporan', 'Rpt.Penjualan', 'fa fa-circle', 'laporan-penjualan', '1', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('59', '2', 't_terima_stnk', 'TT STNK & BPKB', 'fa fa-circle', 'terima-stnk', '6', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('60', '1', '-', 'Owner Setting', 'fa fa-circle', 'owner', '10', '1');
INSERT INTO `menus` (`id`, `parent`, `module`, `name`, `icon`, `slug`, `number`, `status`) VALUES ('65', '6', 'backup_db', 'Backup Database', 'fa fa-circle', 'backup-database', '1', '1');


#
# TABLE STRUCTURE FOR: motor_keluar
#

DROP TABLE IF EXISTS `motor_keluar`;

CREATE TABLE `motor_keluar` (
  `id_motor_keluar` int(11) NOT NULL AUTO_INCREMENT,
  `kode_motor_keluar` varchar(30) DEFAULT NULL,
  `id_gudang_in` int(11) DEFAULT NULL,
  `id_gudang_out` int(11) DEFAULT NULL,
  `tgl_motor_keluar` date DEFAULT NULL,
  `kode_po_motor_keluar` varchar(20) DEFAULT NULL,
  `kode_do_motor_keluar` varchar(20) DEFAULT NULL,
  `pic_motor_keluar` varchar(30) DEFAULT NULL,
  `keterangan_motor_keluar` text,
  `status_motor_keluar` enum('1','2','3') DEFAULT '1',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_motor_keluar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: penerimaan_aksesoris
#

DROP TABLE IF EXISTS `penerimaan_aksesoris`;

CREATE TABLE `penerimaan_aksesoris` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aksesoris_id` int(11) DEFAULT NULL,
  `jumlah` float DEFAULT NULL,
  `tanggal_terima` datetime DEFAULT NULL,
  `status_add_or_min` enum('1','2') DEFAULT '1' COMMENT '1=>tambah,2=>kurang',
  `keterangan` text,
  `gudang_id` int(11) DEFAULT NULL,
  `aksesoris_status` enum('1','2','3') DEFAULT '1',
  `by_system` enum('1','2') DEFAULT '1',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: penerimaan_motor
#

DROP TABLE IF EXISTS `penerimaan_motor`;

CREATE TABLE `penerimaan_motor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nopolisi` varchar(15) DEFAULT NULL COMMENT 'mobil yang membawa motor',
  `tgl_sj` date DEFAULT NULL,
  `no_sj` varchar(15) DEFAULT NULL,
  `no_so` varchar(15) DEFAULT NULL,
  `nomesin` varchar(25) DEFAULT NULL,
  `norangka` varchar(25) DEFAULT NULL,
  `tipe` varchar(25) DEFAULT NULL,
  `warna` varchar(10) DEFAULT NULL,
  `tahun` varchar(10) DEFAULT NULL,
  `kdgudang` int(11) DEFAULT NULL,
  `tglupload` datetime DEFAULT NULL,
  `namafile` varchar(200) DEFAULT NULL,
  `m_status` enum('1','2','3') DEFAULT '1',
  `status_jual` enum('1','2','3','4') DEFAULT '1' COMMENT '1=belum terjual, 2=sudah terjual, 3=retur,4=inprocess',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=latin1;

INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('1', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK1E1419743', 'MH1JBK116HK423564', 'NFT13C01', 'BLACK GREE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('2', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK1E1420249', 'MH1JBK111HK424105', 'NFT13C01', 'BLACK GREE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('3', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK1E1425242', 'MH1JBK118HK428989', 'NFT13C01', 'BLACK BLUE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('4', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK1E1427971', 'MH1JBK11XHK431540', 'NFT13C01', 'BLACK RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('5', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK1E1431310', 'MH1JBK111HK435296', 'NFT13C01', 'BLACK RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('6', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK1E1431788', 'MH1JBK113HK433341', 'NFT13C01', 'BLACK RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('7', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK1E1432483', 'MH1JBK111HK437131', 'NFT13C01', 'BLACK RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('8', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK1E1434871', 'MH1JBK113HK438586', 'NFT13C01', 'BLACK RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('9', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK3E1204600', 'MH1JBK318HK205929', 'NFT13C03', 'BLACK RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('10', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK3E1205400', 'MH1JBK312HK206588', 'NFT13C03', 'BLACK RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('11', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK3E1205985', 'MH1JBK315HK207539', 'NFT13C03', 'WHITE RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('12', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK3E1206421', 'MH1JBK314HK207760', 'NFT13C03', 'WHITE RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('13', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK3E1206662', 'MH1JBK31XHK207813', 'NFT13C03', 'WHITE RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('14', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBK3E1206713', 'MH1JBK310HK205083', 'NFT13C03', 'BLACK RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('15', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBP1E1508803', 'MH1JBP119HK514065', 'AFX21C08', 'MERAH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('16', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBP1E1536605', 'MH1JBP116HK541952', 'AFX21C08', 'MERAH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('17', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBP1E1550557', 'MH1JBP110HK555622', 'AFX21C08', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('18', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBP1E1550662', 'MH1JBP11XHK555613', 'AFX21C08', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('19', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBP1E1552678', 'MH1JBP11XHK557653', 'AFX21C08', 'MERAH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('20', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBP1E1552679', 'MH1JBP114HK557650', 'AFX21C08', 'MERAH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('21', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBP1E1552687', 'MH1JBP117HK557643', 'AFX21C08', 'MERAH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('22', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBP1E1552813', 'MH1JBP115HK558435', 'AFX21C08', 'MERAH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('23', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBP1E1552855', 'MH1JBP117HK558498', 'AFX21C08', 'MERAH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('24', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBP1E1554074', 'MH1JBP111HK559081', 'AFX21C08', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('25', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JBP1E1554087', 'MH1JBP114HK559074', 'AFX21C08', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('26', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFA1E1235533', 'MH1JFA111HK242080', 'NC1D1CF1', 'BLACK RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('27', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFA1E1237044', 'MH1JFA119HK243669', 'NC1D1CF1', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('28', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFA1E1237518', 'MH1JFA111HK242810', 'NC1D1CF1', 'BLACK RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('29', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFA1E1238455', 'MH1JFA119HK243946', 'NC1D1CF1', 'MERAH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('30', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFA1E1238756', 'MH1JFA115HK244141', 'NC1D1CF1', 'MERAH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('31', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFA1E1238814', 'MH1JFA11XHK244300', 'NC1D1CF1', 'MERAH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('32', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFA1E1238890', 'MH1JFA117HK244271', 'NC1D1CF1', 'BLACK RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('33', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFA1E1239005', 'MH1JFA114HK244504', 'NC1D1CF1', 'BLACK RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('34', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFA1E1240388', 'MH1JFA112HK245909', 'NC1D1CF1', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('35', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFP1E2365711', 'MH1JFP127GK377638', 'X12BN4LO', 'BLACK', '2016', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('36', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFS1E1381768', 'MH1JFS112HKK389014', 'YG02N2L1', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('37', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFS1E1383536', 'MH1JFS110HK391277', 'YG02N2L1', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('38', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFS1E1383917', 'MH1JFS118HK390569', 'YG02N2L1', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('39', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFS1E1388241', 'MH1JFS115HK395423', 'YG02N2L1', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('40', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFS1E1388242', 'MH1JFS116HK395415', 'YG02N2L1', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('41', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFS1E1388245', 'MH1JFS116HK395494', 'YG02N2L1', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('42', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFS2E1084470', 'MH1JFS216HK083254', 'YG2N2LAA', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('43', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFS2E1084478', 'MH1JFS219HK083250', 'YG2N2LAA', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('44', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFT1E1082077', 'MH1JFT117HK082525', 'YG2N15L1', 'PUTIH MERA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('45', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFT1E1082421', 'MH1JFT11XHK082986', 'YG2N15L1', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('46', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFT1E1083557', 'MH1JFT112HK084067', 'YG2N15L1', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('47', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFT1E1085867', 'MH1JFT110HK086223', 'YG2N15LA', 'PUTIH MAGE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('48', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFU1E1969413', 'MH1JFU111HK965381', 'EF2N11S2', 'BLACK RED ', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('49', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFU1E1969415', 'MH1JFU11XHK965380', 'EF2N11S2', 'BLACK RED ', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('50', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFU1E1991399', 'MH1JFU11XHK976587', 'EF2N11S2', 'BLACK RED ', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('51', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFU1E1991667', 'MH1JFU119HK976743', 'EF2N11S2', 'BLACK RED ', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('52', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFU1E1991681', 'MH1JFU111HK976770', 'EF2N11S2', 'BLACK RED ', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('53', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFU1E1991683', 'MH1JFU116HK976764', 'EF2N11S2', 'BLACK RED ', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('54', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFU1E1991993', 'MH1JFU11XHK977559', 'EF2N11S2', 'WHITE RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('55', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFU1E1992010', 'MH1JFU119HK977567', 'EF2N11S2', 'WHITE RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('56', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFV1E1589807', 'MH1JFV113HK585917', 'EF02N12S', 'BLACK GREE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('57', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFV1E1692628', 'MH1JFV117HK685986', 'EF2N1252', 'BLACK YELL', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('58', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFV1E1693099', 'MH1JFV117HK686782', 'EF2N1252', 'RED WHITE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('59', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFV1E1696300', 'MH1JFV114HK690188', 'EF2N1252', 'BLACK YELL', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('60', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFV1E1697218', 'MH1JFV111HK690746', 'EF2N1252', 'WHITE RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('61', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFV1E1697259', 'MH1JFV116HK690774', 'EF2N1252', 'WHITE RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('62', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFV1E1697290', 'MH1JFV119HK690817', 'EF2N1252', 'RED WHITE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('63', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFV1E1697291', 'MH1JFV110HK690818', 'EF2N1252', 'RED WHITE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('64', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFV1E1697342', 'MH1JFV119HK690946', 'EF2N1252', 'WHITE RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('65', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFV1E1697346', 'MH1JFV113HK690974', 'EF2N1252', 'WHITE RED', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('66', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFV1E1830226', 'MH1JFV118HK826395', 'EF02N12S', 'BLACK GREE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('67', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFV1E1969418', 'MH1JFV111HK965378', 'EF2N11S2', 'BLACK RED ', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('68', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFX1E1273442', 'MH1JFX110HK27644', 'D1A2N18S', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('69', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFX1E1293996', 'MH1JFX110HK296554', 'D1A2N18S', 'MERAH PUTI', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('70', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFX1E1294016', 'MH1JFX115HK296601', 'D1A2N18S', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('71', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFX1E1296015', 'MH1JFX110HK295467', 'D1A2N8A', 'GREY', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('72', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFX1E1380962', 'MH1JM111XHK397586', 'D1B2N3LA', 'MAGENTA HI', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('73', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFY1E1080653', 'MH1JFY119HK083625', 'D1A2N19S', 'MERAH PUTI', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('74', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFY1E1080689', 'MH1JFY117HK083672', 'D1A2N19S', 'MERAH PUTI', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('75', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFY1E1087539', 'MH1JFY118HK088847', 'D1A2N19S', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('76', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFY1E1088303', 'MH1JFY119HK089697', 'D1A2N19S', 'PUTIH HITA', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('77', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1469249', 'MH1JFZ114HK480923', 'D1B2N2L2', 'BIRU PUTIH', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('78', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E163246', 'MH1JFZ114HK634999', 'D1B2N6L2', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('79', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1883505', 'MH1JFZ110HK897541', 'D1B2N6L2', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('80', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1883521', 'MH1JFZ117HK897522', 'D1B2N6L2', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('81', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1883529', 'MH1JFZ110HK897524', 'D1B2N6L2', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('82', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1883540', 'MH1JFZ113HK897534', 'D1B2N6L2', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('83', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1883545', 'MH1JFZ112HK897539', 'D1B2N6L2', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('84', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1883547', 'MH1JFZ114HK897543', 'D1B2N6L2', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('85', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1883549', 'MH1JFZ11XHK897546', 'D1B2N6L2', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('86', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1962003', 'MH1JFZ11XHK953792', 'D1B2N6L2', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('87', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1962084', 'MH1JFZ117HK953832', 'D1B2N6L2', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('88', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1969804', 'MH1JFZ119HK961575', 'D1B2N6L2', 'WHITE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('89', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1972499', 'MH1JFZ119HK963133', 'D1B2N6L2', 'WHITE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('90', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1978751', 'MH1JFZ117HK971179', 'D1B2N6L2', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('91', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1978980', 'MH1JFZ114HK971740', 'D1B2N6L2', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('92', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1981576', 'MH1JFZ116HK970847', 'D1B2N6L2', 'WHITE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('93', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ1E1981577', 'MH1JFZ118HK970848', 'D1B2N6L2', 'WHITE', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('94', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ2E1044480', 'MH1JM216HK039439', 'D1I2NM1', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('95', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ2E1124325', 'MH1JFZ210HK119335', 'D1I2NM1', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('96', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ2E1124445', 'MH1JFZ213HK119443', 'D112NM1', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('97', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ2E1125063', 'MH1JFZ211HK119859', 'D1I2NM1', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('98', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ2E1131939', 'MH1JFZ21XHK129371', 'D1I2NM1', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('99', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ2E1132205', 'MH1JFZ212HK129235', 'D1I2NM1', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('100', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ2E1132228', 'MH1JFZ215HK129259', 'D1I2NM1', 'BLACK', '2017', '1', '2017-08-12 12:39:58', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:39:58', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('101', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JFZ2E1132485', 'MH1JFZ216HK129514', 'D1I2NM1', 'WHITE', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('102', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM11E1175545', 'MH1JM1116HK183941', 'D1B2N3L2', 'MERAH PUTI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('103', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM11E122638', 'MH1JM1116HK133736', 'D1B2N3LA', 'BIRU PUTIH', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('104', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM11E1382213', 'MH1JM111XHK398835', 'D1B2N3LA', 'BIRU PUTIH', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('105', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM11E1387587', 'MH1JM1119HK406214', 'D1B2N3LA', 'MAGENTA HI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('106', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM11E1387597', 'MH1JM1115HK406226', 'D1B2N3LA', 'MAGENTA HI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('107', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM11E1387598', 'MH1JM1117HK406227', 'D1B2N3LA', 'MAGENTA HI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('108', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM11E1390474', 'MH1JM1118HK403904', 'D1B2N3LA', 'MERAH PUTI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('109', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM21E1331206', 'MH1JM2111HK329764', 'D1B2N2L2', 'BLACK', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('110', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM21E1357783', 'MH1JM2113HK364483', 'D1B2N2L2', 'MERAH PUTI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('111', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM21E1417749', 'MH1JM2113HK428635', 'D1B2N2L2', 'BLACK', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('112', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM21E1471194', 'MH1JM2119HK476706', 'D1B2N2L2', 'MERAH PUTI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('113', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM21E1491544', 'MH1JM2113HK502300', 'D1B2N2L2', 'BIRU PUTIH', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('114', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM21E1500251', 'MH1JM2112HK498577', 'D1B2N2L2', 'MERAH PUTI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('115', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM21E1500489', 'MH1JM2116HK498825', 'D1B2N2L2', 'BLACK', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('116', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM21E1500498', 'MH1JM2117HK498820', 'D1B2N2L2', 'BLACK', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('117', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM21E1500499', 'MH1JM2119HK498821', 'D1B2N2L2', 'BLACK', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('118', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM21E1500524', 'MH1JM2114HK498838', 'D1B2N2L2', 'BIRU PUTIH', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('119', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM21E1500525', 'MH1JM2116HK498839', 'D1B2N2L2', 'BIRU PUTIH', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('120', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM21E1500619', 'MH1JM2115HK498931', 'D1B2N2L2', 'BIRU PUTIH', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('121', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'JM31E1222174', 'MH1JM3111HK215298', 'FIC2N2AB', 'HITAM PUTI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('122', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KB11E1103950', 'MH1KB111XHK102609', 'Y3B2R17S', 'MERAH PUTI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('123', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KB11E1103951', 'MH1KB1118HK102608', 'Y3B2R17S', 'MERAH PUTI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('124', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KB11E1117357', 'MH1KB1112HK117122', 'Y3B2R71B', 'BLACK', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('125', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KB11E1131580', 'MH1KB1112HK132137', 'Y3B2R71B', 'BLACK', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('126', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KB21E1023865', 'MH1KB2118GK025002', 'G2E02RLA', 'RED', '2016', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('127', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KB21E1031478', 'MH1KB2116GK020364', 'G2E02RLA', 'BLACK', '2016', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('128', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KB21E1040810', 'MH1KB211XHK042420', 'G2E02RS1', 'HITAM MERA', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('129', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KB21E1040860', 'MH1KB2113HK042467', 'G2E02RS1', 'HITAM MERA', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('130', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC51E1090452', 'MH1KC5110HK090670', 'GL15BDF2', 'BLACK RED', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('131', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC52E1334677', 'MH1KC5215HK338281', 'GL15BF2A', 'RED', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('132', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC52E1336682', 'MH1JKC5210HK340116', 'GL15BF2A', 'WHITE', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('133', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC52E1347970', 'MH1KC5210HK351942', 'GL15BF2A', 'WHITE', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('134', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC52E1348069', 'MH1KC5216HK351945', 'GL15BF2A', 'WHITE', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('135', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC52E1348544', 'MH1KC5214HK352107', 'GL15BF2A', 'RED', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('136', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC52E1348651', 'MH1KC5217HK352084', 'GL15BF2A', 'RED', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('137', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC52E1348675', 'MH1KC5219HK352023', 'GL15BF2A', 'WHITE', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('138', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC52E1349638', 'MH1KC5214HK353158', 'GL15BF2A', 'BLACK RED', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('139', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC52E1349976', 'MH1KC5217HK354160', 'GL15BF2A', 'BLACK BLUE', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('140', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC52E1350732', 'MH1KC5218HK354183', 'GL15BF2A', 'BLACK BLUE', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('141', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC52E1351369', 'MH1KC5219HK354810', 'GL15BF2A', 'RED', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('142', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC81E1150433', 'MH1KC8118HK157811', 'H5C2R2SJ', 'BLACK RED', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('143', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC81E1150448', 'MH1KC8115HK157829', 'H5C2R2SJ', 'BLACK RED', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('144', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC81E1152775', 'MH1KC8113HK159191', 'H5C2R2SJ', 'BLACK YELL', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('145', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC81E1162243', 'MH1KC811XHK164839', 'H5C2R2SJ', 'WHITE RED', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('146', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC81E1162282', 'MH1KC8119HK164881', 'H5C2R2SJ', 'WHITE RED', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('147', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC82E1142584', 'MH1KC8216HK145073', 'H5C2R2MA', 'HITAM MERA', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('148', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC82E1142598', 'MH1KC821XHK145089', 'H5C2R2MA', 'HITAM MERA', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('149', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC82E1144277', 'MH1KC8216HK149494', 'H5C2R2JA', 'RED', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('150', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC82E1145952', 'MH1KB214HK148862', 'H5C2R2MA', 'HITAM MERA', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('151', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC82E1147746', 'MH1KC8215HK152029', 'H5C2R2JA', 'RED', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('152', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC91E1115665', 'MH1KC9114HK124505', 'P5E02MBJ', 'ORANGE PUT', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('153', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC91E1115688', 'MH1KC9117HK124515', 'P5E02MBJ', 'ORANGE PUT', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('154', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC91E1116612', 'MH1KC9115HK121452', 'P5E02S1J', 'HITAM PUTI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('155', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC91E1120785', 'MH1KC9114HK120292', 'P5E02MBJ', 'ORANGE PUT', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('156', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC91E1120947', 'MH1KC9112HK115480', 'P5E02MBJ', 'ORANGE PUT', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('157', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC91E1125355', 'MH1KC9113HK129940', 'P5E02S1J', 'HITAM PUTI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('158', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC91E1130761', 'MH1KC9117HK137796', 'P5E02S1J', 'MERAH PUTI', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('159', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KC91E1134967', 'MH1KC9113HK138749', 'P5E02S1J', 'HITAM MERA', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);
INSERT INTO `penerimaan_motor` (`id`, `nopolisi`, `tgl_sj`, `no_sj`, `no_so`, `nomesin`, `norangka`, `tipe`, `warna`, `tahun`, `kdgudang`, `tglupload`, `namafile`, `m_status`, `status_jual`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('160', 'B1', '2017-08-12', 'STOK OP', 'STOK OP', 'KF11E2214379', 'MH1KF1122HK215242', 'K1H2N4A2', 'BLACK', '2017', '1', '2017-08-12 12:40:04', '20170812123935-templateTerimaMotor.xlsx', '1', '1', '6', NULL, NULL, '2017-08-12 12:40:04', NULL, NULL);


#
# TABLE STRUCTURE FOR: penerimaan_motor_temp
#

DROP TABLE IF EXISTS `penerimaan_motor_temp`;

CREATE TABLE `penerimaan_motor_temp` (
  `id_temp` int(11) NOT NULL AUTO_INCREMENT,
  `nopolisi` varchar(15) DEFAULT NULL COMMENT 'mobil yang membawa motor',
  `tgl_sj` date DEFAULT NULL,
  `no_sj` varchar(15) DEFAULT NULL,
  `no_so` varchar(15) DEFAULT NULL,
  `nomesin` varchar(25) NOT NULL DEFAULT '',
  `norangka` varchar(25) NOT NULL DEFAULT '',
  `tipe` varchar(25) DEFAULT NULL,
  `warna` varchar(10) DEFAULT NULL,
  `tahun` varchar(10) DEFAULT NULL,
  `kdgudang` int(11) DEFAULT NULL,
  `tglupload` datetime DEFAULT NULL,
  `namafile` varchar(200) DEFAULT NULL,
  `m_status` enum('') DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_temp`,`norangka`,`nomesin`),
  UNIQUE KEY `unique_A_B` (`nomesin`,`norangka`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_harga_motor
#

DROP TABLE IF EXISTS `t_harga_motor`;

CREATE TABLE `t_harga_motor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `noso` varchar(25) NOT NULL,
  `cara_pembelian` varchar(15) DEFAULT NULL,
  `marketing` varchar(75) DEFAULT NULL,
  `leasing` varchar(15) DEFAULT NULL,
  `dp_system` float DEFAULT NULL,
  `diskon` float DEFAULT NULL,
  `tagih` float DEFAULT NULL,
  `dp` float DEFAULT NULL,
  `sisa_hutang` float DEFAULT NULL,
  `dp_lunas` enum('1','2') DEFAULT '1' COMMENT '1=>belum lunas, 2=>lunas',
  `fee` float DEFAULT NULL,
  `m_status` int(2) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_kwitansi_diskon
#

DROP TABLE IF EXISTS `t_kwitansi_diskon`;

CREATE TABLE `t_kwitansi_diskon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nokwitansi` varchar(25) DEFAULT NULL,
  `noso` varchar(25) DEFAULT NULL,
  `diskon` double DEFAULT NULL,
  `m_status` int(2) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_kwitansi_fee
#

DROP TABLE IF EXISTS `t_kwitansi_fee`;

CREATE TABLE `t_kwitansi_fee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nokwitansi` varchar(25) DEFAULT NULL,
  `noso` varchar(25) DEFAULT NULL,
  `fee` double DEFAULT NULL,
  `m_status` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_kwitansi_leasing
#

DROP TABLE IF EXISTS `t_kwitansi_leasing`;

CREATE TABLE `t_kwitansi_leasing` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nokwitansi` varchar(25) DEFAULT NULL,
  `noso` varchar(25) DEFAULT NULL,
  `dp_system` float DEFAULT NULL,
  `tagih` int(10) DEFAULT NULL,
  `subsidi1` float DEFAULT NULL,
  `subsidi2` float DEFAULT NULL,
  `status_rekap` int(11) DEFAULT '0',
  `m_status` int(5) DEFAULT NULL,
  `sys_create_user` varchar(10) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_pdi
#

DROP TABLE IF EXISTS `t_pdi`;

CREATE TABLE `t_pdi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kdpdi` varchar(25) DEFAULT NULL,
  `noso` varchar(25) DEFAULT NULL,
  `nosj` varchar(25) DEFAULT NULL,
  `tgl_pdi` date DEFAULT NULL,
  `pic` varchar(25) DEFAULT NULL,
  `gudang_id` int(11) DEFAULT NULL,
  `sj_print_date` date DEFAULT NULL,
  `sj_print_status` enum('1','2') DEFAULT '1' COMMENT '1=>not printed, 2=>printed',
  `sj_print_user_id` int(11) DEFAULT NULL,
  `m_status` int(2) DEFAULT NULL,
  `sys_create_date` date DEFAULT NULL,
  `sys_update_date` date DEFAULT NULL,
  `sys_delete_date` date DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_pdi_detail
#

DROP TABLE IF EXISTS `t_pdi_detail`;

CREATE TABLE `t_pdi_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pdi_id` int(11) DEFAULT NULL,
  `aksesoris_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_pembayaran
#

DROP TABLE IF EXISTS `t_pembayaran`;

CREATE TABLE `t_pembayaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nokwitansi` varchar(25) DEFAULT NULL,
  `noso` varchar(25) DEFAULT NULL,
  `transaksi` int(11) DEFAULT NULL,
  `nominal` double DEFAULT NULL,
  `tgl_dp` date DEFAULT NULL,
  `m_status` int(2) DEFAULT '1',
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_pencairan_leasing
#

DROP TABLE IF EXISTS `t_pencairan_leasing`;

CREATE TABLE `t_pencairan_leasing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_tagihan` varchar(100) DEFAULT NULL,
  `tgl_tagihan` datetime DEFAULT NULL,
  `cabang_leasing` varchar(1000) DEFAULT NULL,
  `tgl_pencairan` datetime DEFAULT NULL,
  `no_bukti_potongan` varchar(100) DEFAULT NULL,
  `tot_tagihan` double DEFAULT NULL,
  `tot_pencairan` double DEFAULT NULL,
  `sisa_tagihan` double DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `m_status` enum('1','2','3','4') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_pencairan_leasing_detail
#

DROP TABLE IF EXISTS `t_pencairan_leasing_detail`;

CREATE TABLE `t_pencairan_leasing_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_tagihan` varchar(100) DEFAULT NULL,
  `id_kwitansi` int(11) DEFAULT NULL,
  `tgl_pencairan` date DEFAULT NULL,
  `no_bukti_potongan` varchar(100) DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `m_status` enum('1','2','3','4') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_penjualan
#

DROP TABLE IF EXISTS `t_penjualan`;

CREATE TABLE `t_penjualan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nosj` varchar(25) DEFAULT NULL,
  `noso` varchar(25) DEFAULT NULL,
  `nokonsumen` varchar(25) DEFAULT NULL,
  `ktp` varchar(30) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `nomsn` varchar(20) DEFAULT NULL,
  `warna_motor` varchar(100) DEFAULT NULL,
  `harga_otr` float DEFAULT NULL,
  `m_status` enum('1','2','3','4','5') DEFAULT NULL COMMENT '1=>active,2=>not active,3=>deleted,4=>void,5=>process_finish',
  `status_kwitansi` int(11) DEFAULT '0',
  `fee_print` enum('1','2') DEFAULT '1',
  `fee_print_user` int(11) DEFAULT NULL,
  `discount_print` enum('1','2') DEFAULT '1',
  `discount_print_user` int(11) DEFAULT NULL,
  `fee_print_date` datetime DEFAULT NULL,
  `discount_print_date` date DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `noso` (`noso`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO `t_penjualan` (`id`, `nosj`, `noso`, `nokonsumen`, `ktp`, `tanggal`, `nomsn`, `warna_motor`, `harga_otr`, `m_status`, `status_kwitansi`, `fee_print`, `fee_print_user`, `discount_print`, `discount_print_user`, `fee_print_date`, `discount_print_date`, `sys_create_user`, `sys_update_user`, `sys_delete_user`, `sys_create_date`, `sys_update_date`, `sys_delete_date`) VALUES ('28', NULL, 'SO/MKA-2017/V/000001', NULL, '3171032402860014', '2017-05-06', 'JM21E1353387', 'MP', '15425000', '1', '1', '1', NULL, '1', NULL, NULL, NULL, '6', NULL, NULL, '2017-05-06 16:48:50', NULL, NULL);


#
# TABLE STRUCTURE FOR: t_rekap_tagihan
#

DROP TABLE IF EXISTS `t_rekap_tagihan`;

CREATE TABLE `t_rekap_tagihan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_tagihan` varchar(100) DEFAULT NULL,
  `tgl_tagihan` datetime DEFAULT NULL,
  `tot_tagihan` double DEFAULT NULL,
  `sisa_tagihan` double DEFAULT NULL,
  `kdleasing` varchar(100) DEFAULT NULL,
  `cabang_leasing` varchar(1000) DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `m_status` enum('1','2','3','4') DEFAULT NULL,
  `status_rekap` int(11) DEFAULT '0',
  `status_pencairan` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_rekap_tagihan_detail
#

DROP TABLE IF EXISTS `t_rekap_tagihan_detail`;

CREATE TABLE `t_rekap_tagihan_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kwitansi` int(11) DEFAULT NULL,
  `no_kwitansi` varchar(100) DEFAULT NULL,
  `tgl_kwitansi` datetime DEFAULT NULL,
  `nomor_tagihan` varchar(100) DEFAULT NULL,
  `price_list` varchar(100) DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `m_status` enum('1','2','3','4') DEFAULT NULL,
  `status_rekap` int(11) DEFAULT '0',
  `status_pencairan` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_stnk
#

DROP TABLE IF EXISTS `t_stnk`;

CREATE TABLE `t_stnk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_so` varchar(30) DEFAULT NULL,
  `no_process` varchar(50) DEFAULT NULL,
  `stnk_process_date` date DEFAULT NULL,
  `stnk_estimate_date` date DEFAULT NULL,
  `bpkb_process_date` date DEFAULT NULL,
  `bpkb_estimate_date` date DEFAULT NULL,
  `stnk_status` int(2) DEFAULT '1',
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime NOT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `t_stnk` (`id`, `no_so`, `no_process`, `stnk_process_date`, `stnk_estimate_date`, `bpkb_process_date`, `bpkb_estimate_date`, `stnk_status`, `sys_create_date`, `sys_update_date`, `sys_delete_date`, `sys_create_user`, `sys_update_user`, `sys_delete_user`) VALUES ('2', 'SO/MKA-2017/V/000001', 'SB-2017-05-000001', '2017-05-06', '2017-05-20', '2017-05-06', '2017-08-04', '1', '2017-05-06 16:53:26', '0000-00-00 00:00:00', NULL, '6', NULL, NULL);


#
# TABLE STRUCTURE FOR: t_stnk_bpkb
#

DROP TABLE IF EXISTS `t_stnk_bpkb`;

CREATE TABLE `t_stnk_bpkb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `noproses` varchar(25) DEFAULT NULL,
  `noso` varchar(25) DEFAULT NULL,
  `tgl_proses_stnk` date DEFAULT NULL,
  `tgl_proses_bpkb` date DEFAULT NULL,
  `estimasi_stnk_selesai` date DEFAULT NULL,
  `estimasi_bpkb_selesai` date DEFAULT NULL,
  `ktp_stnk` varchar(35) DEFAULT NULL,
  `m_status` int(2) DEFAULT NULL,
  `sys_create_date` date DEFAULT NULL,
  `sys_update_date` date DEFAULT NULL,
  `sys_delete_date` date DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_stnk_customer
#

DROP TABLE IF EXISTS `t_stnk_customer`;

CREATE TABLE `t_stnk_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `t_stnk_id` int(11) DEFAULT NULL,
  `t_stnk_ktp` varchar(30) DEFAULT NULL,
  `t_stnk_nama` varchar(50) DEFAULT NULL,
  `t_stnk_tempat_lahir` varchar(30) DEFAULT NULL,
  `t_stnk_tgl_lahir` date DEFAULT NULL,
  `t_stnk_jenis_kelamin` enum('P','W') DEFAULT 'P',
  `t_stnk_alamat` text,
  `t_stnk_rt` varchar(5) DEFAULT NULL,
  `t_stnk_rw` varchar(5) DEFAULT NULL,
  `t_stnk_wilayah` text,
  `t_stnk_kelurahan` varchar(100) DEFAULT NULL,
  `t_stnk_kecamatan` varchar(100) DEFAULT NULL,
  `t_stnk_telepon` varchar(20) DEFAULT NULL,
  `t_stnk_handphone` varchar(20) DEFAULT NULL,
  `sys_create_date` date DEFAULT NULL,
  `sys_update_date` date DEFAULT NULL,
  `sys_delete_date` date DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_terima_stnk
#

DROP TABLE IF EXISTS `t_terima_stnk`;

CREATE TABLE `t_terima_stnk` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `t_stnk_id` int(11) DEFAULT NULL,
  `birojasa_id` int(11) DEFAULT NULL,
  `t_terima_no_polisi` varchar(30) DEFAULT NULL,
  `t_terima_no_stnk` varchar(30) DEFAULT NULL,
  `t_terima_no_bpkb` varchar(30) DEFAULT NULL,
  `t_terima_tgl_stnk` date DEFAULT NULL,
  `t_terima_tgl_bpkb` date DEFAULT NULL,
  `t_terima_no_bon_1` varchar(20) DEFAULT NULL,
  `t_terima_no_bon_2` varchar(20) DEFAULT NULL,
  `t_terima_add_biaya_1` float DEFAULT NULL,
  `t_terima_add_biaya_2` float DEFAULT NULL,
  `t_terima_add_biaya_1_description` text,
  `t_terima_add_biaya_2_description` text,
  `t_terima_status` int(11) DEFAULT '1',
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `t_stnk_id` (`t_stnk_id`),
  CONSTRAINT `t_stnk_id` FOREIGN KEY (`t_stnk_id`) REFERENCES `t_stnk` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_void
#

DROP TABLE IF EXISTS `t_void`;

CREATE TABLE `t_void` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `noso` varchar(255) DEFAULT NULL,
  `void_user_id` int(11) DEFAULT NULL,
  `void_description` text,
  `void_date` datetime DEFAULT NULL,
  `sys_create_user` int(11) DEFAULT NULL,
  `sys_update_user` int(11) DEFAULT NULL,
  `sys_delete_user` int(11) DEFAULT NULL,
  `sys_create_date` datetime DEFAULT NULL,
  `sys_update_date` datetime DEFAULT NULL,
  `sys_delete_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `noso` (`noso`),
  CONSTRAINT `noso` FOREIGN KEY (`noso`) REFERENCES `t_penjualan` (`noso`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

